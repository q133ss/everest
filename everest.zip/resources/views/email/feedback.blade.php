<h1>Форма обратной связи</h1>

<p><strong>Имя:</strong> {{ $data->name }}</p>
<p><strong>Телефон:</strong> {{ $data->phone }}</p>
<p><strong>Комментарий:</strong> {{ $data->comment }}</p>
