@extends('layouts.site')
@section('title','Магазин')
@section('content')
    <div class="shop">
        <div class="container">
            <p class="shop__title">Магазин <span>В разработке...</span>
            </p>
        </div>
    </div>
@endsection
