<?php $__env->startSection('content'); ?>
<?php
    function redirect(){
        return to_route('admin.index');
    }
    redirect();
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/home.blade.php ENDPATH**/ ?>