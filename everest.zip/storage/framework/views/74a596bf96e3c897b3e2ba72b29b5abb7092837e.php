<?php $__env->startSection('title', 'Тренеры'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                
                <a href="<?php echo e(route('admin.trainer.create')); ?>" class="btn btn-success mb-3">Добавить</a>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Фото</th>
                        <th>Имя</th>
                        <th>Секция</th>
                        <th style="width: 40px;">Изменить</th>
                        <th style="width: 20px;">Удалить</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($trainer->id); ?></th>
                            <td><img src="<?php echo e($trainer->photo); ?>" width="100px" alt=""></td>
                            <td><?php echo e($trainer->name); ?></td>
                            <td><?php echo e($trainer->section->title); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.trainer.edit', $trainer->id)); ?>" class="btn btn-info">Изменить</a>
                            </td>
                            <td>
                                <form action="<?php echo e(route('admin.trainer.destroy', $trainer->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-dark delete-btn"><i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/admin/trainers/index.blade.php ENDPATH**/ ?>