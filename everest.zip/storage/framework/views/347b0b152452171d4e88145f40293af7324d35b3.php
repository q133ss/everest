<?php $__env->startSection('title', 'Изменить неделю'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('admin.week.update', $week->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group col-md-6">
                    <label for="inputEmail4" class="col-form-label">Дата</label>
                    <input type="text" name="date" value="<?php echo e($week->date); ?>" placeholder="07 февраля - 14 февраля" class="form-control" id="inputEmail4">
                </div>
                <div class="form-group col-md-6">
                    <button type="submit" class="btn btn-success">Изменить</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/admin/weeks/edit.blade.php ENDPATH**/ ?>