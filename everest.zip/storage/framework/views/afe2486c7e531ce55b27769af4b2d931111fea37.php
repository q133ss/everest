<?php $__env->startSection('title', 'Добавить тренера'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('admin.trainer.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group col-md-6">
                    <label for="inputEmail4" class="col-form-label">Имя</label>
                    <input type="text" name="name" class="form-control" id="inputEmail4">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail4" class="col-form-label">Фото</label>
                    <input type="file" name="photo" class="form-control" id="inputEmail4">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail5" class="col-form-label">Описание</label>
                    <textarea name="description" class="form-control" id="" cols="30" rows="10"></textarea>
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail6" class="col-form-label">Стаж</label>
                    <input type="text" name="stage" class="form-control" id="inputEmail6">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail6" class="col-form-label">Направления</label>
                    <input type="text" name="directions" class="form-control">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail4" class="col-form-label">Достижения</label>
                    <textarea class="form-control" name="achievements" id="" cols="30" rows="10"></textarea>
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail6" class="col-form-label">Возрастная категория</label>
                    <input type="text" name="age_category" class="form-control">
                </div>

                <div class="form-group col-md-6">
                    <label for="section" class="col-form-label">Секция</label>
                    <select name="section_id" id="" class="form-control">
                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($section->id); ?>"><?php echo e($section->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group col-md-6">
                <button type="submit" class="btn btn-success">Создать</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/admin/trainers/create.blade.php ENDPATH**/ ?>