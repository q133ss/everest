<?php $__env->startSection('title','Магазин'); ?>
<?php $__env->startSection('content'); ?>
    <div class="shop">
        <div class="container">
            <p class="shop__title">Магазин <span>В разработке...</span>
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/shop/index.blade.php ENDPATH**/ ?>