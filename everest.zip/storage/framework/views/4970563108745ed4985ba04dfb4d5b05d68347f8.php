<?php $__env->startSection('title', 'Категории секций'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">

                <a href="<?php echo e(route('admin.section_cat.create')); ?>" class="btn btn-success mb-3">Добавить</a>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Изображение</th>
                        <th>Название</th>
                        <th style="width: 40px;">Изменить</th>
                        <th style="width: 20px;">Удалить</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($cat->id); ?></th>
                        <td><img src="<?php echo e($cat->img); ?>" width="100px" alt=""></td>
                        <td><?php echo e($cat->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.section_cat.edit', $cat->id)); ?>" class="btn btn-info">Изменить</a>
                        </td>
                        <td>
                            <form action="<?php echo e(route('admin.section_cat.destroy', $cat->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                            <button class="btn btn-dark delete-btn"><i class="fa fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/admin/sections/section_cat/index.blade.php ENDPATH**/ ?>