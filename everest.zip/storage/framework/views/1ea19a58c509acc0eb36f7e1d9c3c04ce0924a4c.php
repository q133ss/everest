<?php $__env->startSection('title', 'Единоборства'); ?>
<?php $__env->startSection('content'); ?>
    <section class="page-section directions">
        <div class="container">
            <div class="directions__top">
                <h1 class="title directions__title">Единоборства</h1>
                <!-- <p class="subtitle directions__subtitle">спортивное направление - единоборства</p> -->
                <a class="directions__link" href="<?php echo e(route('schedule')); ?>">
                    <span>Смотреть расписание</span>
                </a>
            </div>
            <ul class="directions__list">

                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="directions__item">
                        <div class="item-directions">
                            <div class="item-directions__img">
                                <img src="<?php echo e($section->img); ?>" alt="<?php echo e($section->title); ?>">
                            </div>
                            <div class="item-directions__info">
                                <h3 class="item-directions__title"><?php echo e($section->title); ?></h3>
                                <p class="item-directions__text"><?php echo e($section->excerpt); ?></p>
                                <button class="button item-directions__btn"></button>
                            </div>
                        </div>
                        <div class="popup-directions" data-modal="directions">
                            <div class="popup-directions__wrapper" data-modal-wrapper>
                                <div class="popup-directions__content" data-modal-content>
                                    <button class="popup-directions__close" data-modal-close aria-label="Закрыть модальное окно">
                                        <svg class="icon">
                                            <use xlink:href="/assets/img/sprite.svg#close"></use>
                                        </svg>
                                    </button>
                                    <div class="popup-directions__img">
                                        <img src="<?php echo e($section->banner); ?>" alt="КРОССФИТ">
                                    </div>
                                    <div class="popup-directions__info">
                                        <p class="popup-directions__title"><?php echo e($section->title); ?></p>
                                        <div class="popup-directions__text">
                                            <?php echo e($section->description); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




























































































































































































































































            </ul>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $('.directions__item').click(function(){
        let modal = $(this).find('.popup-directions')
        modal.addClass('active')
        $('body').attr('style','overflow:hidden')
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/solo.blade.php ENDPATH**/ ?>