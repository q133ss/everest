<?php $__env->startSection('title', 'Новости'); ?>
<?php $__env->startSection('content'); ?>
        <section class="page-section articles">
            <div class="container">
                <h1 class="title articles__title">Новости клуба</h1>
                <p class="subtitle articles__subtitle">новости и анонсы</p>
                <ul class="articles__list">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="articles__item">
                        <article class="item-articles">
                            <div class="item-articles__top">
                                <h2 class="item-articles__title"><?php echo e($post->title); ?></h2>
                                <time class="item-articles__date" datetime="2022-02-02">02.02.2022</time>
                            </div>
                            <div class="item-articles__img">
                                <img src="<?php echo e($post->img); ?>" alt="Какая-либо новость">
                            </div>
                            <p class="item-articles__excerpt"><?php echo e($post->excerpt); ?></p>
                            <button class="button item-articles__btn"></button>
                        </article>
                        <div class="popup-articles" data-modal="articles">
                            <div class="popup-articles__wrapper" data-modal-wrapper>
                                <div class="popup-articles__content" data-modal-content>
                                    <button class="popup-articles__close" data-modal-close aria-label="Закрыть модальное окно">
                                        <svg class="icon">
                                            <use xlink:href="/assets/img/sprite.svg#close"></use>
                                        </svg>
                                    </button>
                                    <div class="popup-articles__img">
                                        <img src="<?php echo e($post->banner); ?>" alt="КРОССФИТ">
                                    </div>
                                    <div class="popup-articles__info">
                                        <p class="popup-articles__title"><?php echo e($post->title); ?></p>
                                        <div class="popup-articles__text">
                                            <p><?php echo e($post->text); ?> </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php echo e($posts->links('pagination.index')); ?>


            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/news/index.blade.php ENDPATH**/ ?>