<?php $__env->startSection('title', 'Тренеры'); ?>
<?php $__env->startSection('content'); ?>
    <section class="page-section coaches">
        <div class="container">
            <h1 class="coaches__title title">Тренеры</h1>
            <p class="subtitle coaches__subtitle">Тренеры нашего зала</p>
            <div class="coaches-slider slider">
                <div class="gradient"></div>
                <div class="swiper">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="coaches-item">
                                <div class="coaches-item__img">
                                    <img src="<?php echo e($trainer->photo); ?>" alt="<?php echo e($trainer->name); ?>">
                                </div>
                                <div class="coaches-item__info">
                                    <p class="coaches-item__name"><?php echo e($trainer->name); ?></p>
                                    <div class="coaches-item__inner">
                                        <p class="coaches-item__point"><?php echo e($trainer->description); ?></p>
                                        <p class="coaches-item__point">Стаж — <?php echo e($trainer->stage); ?></p>
                                        <p class="coaches-item__point">Возрастная категория: <?php echo e($trainer->age_category); ?></p>
                                        <p class="coaches-item__point">Основные направления: <?php echo e($trainer->directions); ?></p>
                                    </div>
                                    <div class="coaches-item__photo">
                                        <img src="<?php echo e($trainer->photo); ?>" alt="">
                                    </div>
                                    <div class="coaches-item__content">
                                        <div class="coaches-accordion" data-accordion="coaches">
                                            <div class="coaches-accordion__top" data-accordion-top>
                                                <p>Читать о тренере</p>
                                            </div>
                                            <div class="coaches-accordion__body" data-accordion-body>
                                                <div class="coaches-accordion__body-content">
                                                    <p>Профессиональные достижения:
                                                        <?php echo e($trainer->achievements); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="coaches-item__btns">
                                        <button class="button coaches-item__request" onclick="$('#order_type').val('Запись к тренеру: <?php echo e($trainer->name); ?>')" data-open-modal="request">Записаться</button>
                                        <a class="button button--outline coaches-item__link" href="./schedule.html">Расписание</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>














































































































































































































































































































































                    </div>
                </div>
                <div class="swiper-navigation coaches-slider__navigation">
                    <button class="coaches-slider__prev slider__prev slider__btn">
                        <svg class="icon">
                            <use xlink:href="/assets/img/sprite.svg#chevron"></use>
                        </svg>
                    </button>
                    <button class="coaches-slider__next slider__next slider__btn">
                        <svg class="icon">
                            <use xlink:href="/assets/img/sprite.svg#chevron"></use>
                        </svg>
                    </button>
                </div>
                <div class="swiper-pagination coaches-slider__pagination"></div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/trainers.blade.php ENDPATH**/ ?>