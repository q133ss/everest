<?php $__env->startSection('title', 'Настройки'); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.settings.save')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label class="col-2 col-form-label">Email администратора</label>
            <div class="col-10">
                <input type="email" class="form-control" name="email" value="<?php echo e($email); ?>">
            </div>
        </div>
        <button type="submit" class="btn btn-success">Сохранить</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/admin/settings.blade.php ENDPATH**/ ?>