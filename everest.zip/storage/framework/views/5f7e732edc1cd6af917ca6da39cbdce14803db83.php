<div class="pagination-articles articles__pagination">
    <span class="pagination-articles__current"><?php echo e($paginator->currentPage()); ?></span>
    <ul class="pagination">
        <li class="control">
            <a href="<?php echo e($paginator->previousPageUrl()); ?>">Предыдущая</a>
        </li>
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                    <?php else: ?>
                    <li>
                        <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                    </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="control">
            <a href="<?php echo e($paginator->nextPageUrl()); ?>">Следующая</a>
        </li>
    </ul>
</div>
<?php /**PATH E:\OpenServer\domains\everest\resources\views/pagination/index.blade.php ENDPATH**/ ?>