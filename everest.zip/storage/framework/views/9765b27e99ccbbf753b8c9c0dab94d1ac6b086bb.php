<?php $__env->startSection('title', 'Добавить категорию секции'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('admin.section_cat.update', $cat->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="inputText3" class="col-form-label">Название</label>
                    <input id="inputText3" name="name" type="text" value="<?php echo e($cat->name); ?>" class="form-control" placeholder="Единоборства">
                </div>

                <div class="custom-file mb-3">
                    <input type="file" name="img" class="custom-file-input" id="customFile">
                    <label class="custom-file-label" for="customFile">Выберите фото</label>
                </div>
                <label for="">Текущее:</label> <br>
                <img src="<?php echo e($cat->img); ?>" alt="">
                <br>
                <button type="submit" class="btn mt-3 btn-success">Создать</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/admin/sections/section_cat/edit.blade.php ENDPATH**/ ?>