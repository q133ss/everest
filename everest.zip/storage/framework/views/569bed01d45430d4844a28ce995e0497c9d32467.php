<?php $__env->startSection('title', 'Изменить категорию секции'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('admin.section.update', $section->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group col-md-6">
                    <label for="inputEmail4" class="col-form-label">Изображение</label>
                    <input type="file" name="img" class="form-control" id="inputEmail4">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail4" class="col-form-label">Категория</label>
                    <select name="category" class="form-control">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if($category->id == $section->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail4" class="col-form-label">Текущее</label>
                    <img width="100%" src="<?php echo e($section->img); ?>" alt="">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail5" class="col-form-label">Название</label>
                    <input type="text" value="<?php echo e($section->title); ?>" name="title" class="form-control" id="inputEmail5">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail6" class="col-form-label">Краткое описание</label>
                    <input type="text" name="excerpt" value="<?php echo e($section->excerpt); ?>" class="form-control" id="inputEmail6">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail6" class="col-form-label">Полное описание</label>
                    <textarea name="description" class="form-control" cols="30" rows="10"><?php echo e($section->description); ?></textarea>
                </div>


                <div class="form-group col-md-6">
                    <label for="inputEmail6" class="col-form-label">Баннер</label>
                    <input name="banner" class="form-control" type="file">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail4" class="col-form-label">Текущий</label>
                    <img width="100%" src="<?php echo e($section->banner); ?>" alt="">
                </div>

                <div class="form-group col-md-6">
                    <label for="inputEmail6" class="col-form-label">Цвет для календаря <small><a href="https://g.co/kgs/ebi2SP" target="_blank">Цвета</a></small> </label>
                    <input name="color" value="<?php echo e($section->color); ?>" class="form-control" placeholder="#f02e46" type="text">
                </div>

                <div class="form-group col-md-6">
                <button type="submit" class="btn btn-success">Обновить</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\everest\resources\views/admin/sections/sections/edit.blade.php ENDPATH**/ ?>